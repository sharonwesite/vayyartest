import os
from flask import Flask, render_template, request

app = Flask(__name__)

def calculate_time_in_chair(log_file_path):
    framecount = 0
    with open(log_file_path, "r") as log_file:
        for line in log_file:
            if "x=" in line and "y=" in line:
                x_value = line.split("x=")[1].split(" ")[0]
                y_value = line.split("y=")[1].split(" ")[0]

                x = float(x_value)
                y = float(y_value)

                # Check if the person is within the specified chair area
                if -0.5 <= x <= 0 and 1.8 <= y <= 2.4:
                    framecount += 1

    # Calculate the time spent in the chair area
    time_in_chair = float(framecount) / 10  # Assuming 10 frames per second
    return time_in_chair

@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/calculate_time', methods=['POST'])
def calculate():
    log_file = request.files['log_file']
    if log_file and log_file.filename.endswith('.log'):
        log_file_path = os.path.join('uploads', log_file.filename)
        log_file.save(log_file_path)
        result = calculate_time_in_chair(log_file_path)
        return render_template('result.html', result=result)
    else:
        return "Invalid log file format. Please upload a .log file."

if __name__ == '__main__':
    app.run(debug=True)
