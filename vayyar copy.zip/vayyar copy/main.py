framecount = 0

# Read and process the log file
with open("tracker_log.log", "r") as log_file:
    for line in log_file:
        if "x=" in line and "y=" in line:
            x_value = line.split("x=")[1].split(" ")[0]
            y_value = line.split("y=")[1].split(" ")[0]

            x = float(x_value)
            y = float(y_value)

            # Check if the person is within the specified chair area
            if -0.5 <= x <= 0 and 1.8 <= y <= 2.4:
                framecount += 1

# Calculate the time spent in the chair area
time_in_chair = float(framecount) / 10  # Assuming 10 frames per second
print(f"The time the person spent near the chair is {time_in_chair:.2f} seconds.")
